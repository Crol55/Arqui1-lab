MatrizLed
==========
MatrizLed es una libreria de [Arduino](http://arduino.cc) para matrices de leds de 8x8 con controladores MAX7219 o MAX7221 
Esta libreria esta basada en [LedControl](https://github.com/wayoda/LedControl)

Descargar
--------
La version mas actualizada se encuentra en el github de [MatrizLed](https://github.com/danidask/MatrizLed) 


Instalación
-------
Las instrucciones para instalar librerias en arduino se encuentra [aquí](http://arduino.cc/en/Guide/Libraries) (ingles)

Uso
-------------
En el IDE de Arduino, en ejemplos -> MatrizLed se encuentran todos los casos de uso.

Limitaciones
-------------
Actualmente soporta letras en mayuscula/minuscula, numeros y espacio. Si necesitas algun otro caracter o funcionalidad, crea un `issue` en github
